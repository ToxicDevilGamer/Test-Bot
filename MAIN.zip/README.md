<h1 align="center">
   Discord.js v14 Command-Handlers
</h1>
<h4 align="center">Commands, Events, Permissions and Cooldown Handlers for Discord.js v14 bot </h4>

# Features
- Commands Handler (toggleOff, maintenance, ownerOnly, guildOnly, aliases, permissions.....)
- Slash Commands Handler (options, choices, autocomplete, toggleOff, ownerOnly.....)
- Events Handler (messageCreate, interactionCreate, ready)
- Advance Permission Handler
- Cooldowns
- Anti Crash
- Error handling

---------
# 💖 Support
- ### [Reflex Development </>](https://discord.gg/)
# 💝 Credit
If consider using this Template, make sure to credit me!
### [Reflex Development](https://discord.com/users/784649693363306518) | [Website](https://u/) | [Discord](https://discord.gg/)
#### Profile 
<img align="left" width="100%" style="margin: 0 10px 0 0;" alt=" " src="https://discord.c99.nl/widget/theme-2/784649693363306518.png">
<img align="left" width="100%" style="margin: 0 10px 0 0;" alt=" " src="https://media.discordapp.net/attachments/877859563016159252/879664980218249216/colour_line2.gif">